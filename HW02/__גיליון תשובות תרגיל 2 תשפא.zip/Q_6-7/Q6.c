#include <stdio.h>

#define TRUE 1
#define FALSE 0

int SimpleCheck(int A[], int r, int q)
{
	return (A[q-1] - A[r-1] > q - r);
}
int SolveB(int A[], int r, int q)
{
	
	if (r + 1 == q)
		return A[r]-1;
	int m = (r + q) / 2;
	if (SimpleCheck(A, r, m) == TRUE)
		return SolveB(A, r, m);
	else
		return SolveB(A, m, q);
}

int  SolveC(int A[], int r, int  q)
{

	if (q < r)
		return FALSE;
	int m = (q + r) / 2;
	if (A[m] == m)
		return TRUE;
	if (A[m] > m)
		return SolveC(A, r, m - 1);
	else
		return SolveC(A, m + 1, q);
}



int main() {
	int A[5] = { 4,5 ,7, 8,9 };
	printf("%d\n", SimpleCheck(A, 1, 5));

	if (SimpleCheck(A, 1, 5) == FALSE)
		printf("There is no such element in A\n");
	else
		printf("%d\n", SolveB(A, 1, 5));

	printf("%d\n", SolveC(A, 1, 5));

	
	return 0;
}

